---
name: mobile-spa-layout-refactor
description: Refactor a mobile-first single-page app (SPA) layout by folding secondary sections and repositioning action buttons to reduce scrolling and visual clutter. Use this skill when the user asks to make a mobile page shorter, collapse infrequently used settings, or move buttons away from primary actions.
agent_created: true
---

# Mobile SPA Layout Refactor

## Overview

This skill provides a repeatable workflow for improving the layout of a mobile-first single-page app (SPA) when the page feels too long, secondary controls compete with primary content, or destructive actions sit too close to frequently used buttons. The approach is: fold, relocate, and simplify.

Typical trigger phrases:
- "页面太长了，可以折叠一下吗"
- "这个设置不常用，能不能收起来"
- "解散/删除按钮和主按钮贴太近了"
- "给排行榜/主内容留更多空间"

## Workflow

### 1. Inspect the Current Layout

Read the relevant HTML/JS/CSS for the page. Identify:
- Sections that are rarely changed but always visible (e.g., share settings, invite creation)
- Two or more related secondary forms that can be merged (e.g., "join group" and "create group")
- Destructive/secondary action buttons placed next to primary actions (e.g., delete next to "view leaderboard")

### 2. Design the Fold

For each collapsible section:
- Add a clickable header with a title and an arrow indicator (`▸` collapsed / `▾` expanded)
- Wrap the content in a container that can be shown/hidden
- Default state: collapsed for infrequently used sections; expanded only when it is the main purpose of the page

For destructive/secondary actions:
- Move them to the card header, aligned with the status badge or title
- Use small icon-only buttons or subtle text links to avoid visual weight
- Keep a confirmation dialog for destructive actions

### 3. Add Reusable CSS Classes

Create a small collapsible component system:

```css
.group-section-card {
  border-radius: var(--radius-xl);
  border: 1px solid var(--border);
  background: var(--card);
  padding: 14px 16px;
  margin-bottom: 14px;
}
.group-section-toggle {
  display: flex;
  justify-content: space-between;
  align-items: center;
  cursor: pointer;
  user-select: none;
}
.group-section-title {
  font-size: 14px;
  font-weight: 600;
  color: var(--text-title);
}
.group-section-arrow {
  font-size: 12px;
  color: var(--text-muted);
  transition: transform .2s;
}
.group-section-content {
  overflow: hidden;
  transition: max-height .25s ease-out;
  max-height: 500px;
}
.group-section-content.collapsed {
  max-height: 0;
}
.group-header-actions {
  display: flex;
  align-items: center;
  gap: 8px;
}
.group-action-icon {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  border: 1px solid var(--border);
  background: var(--bg);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 13px;
  cursor: pointer;
  transition: all .2s;
  padding: 0;
}
.group-action-icon:hover {
  border-color: var(--text-title);
  background: var(--bg-alt);
}
.group-action-icon.danger:hover {
  border-color: var(--danger);
  background: #FFF0F0;
}
```

### 4. Implement the Toggle Function

Add a generic toggle function:

```javascript
window.toggleGroupSection = function(contentId){
  var content = document.getElementById(contentId);
  var arrow = document.getElementById(contentId + '-arrow');
  if (!content) return;
  if (content.classList.contains('collapsed')) {
    content.classList.remove('collapsed');
    if (arrow) arrow.textContent = '▾';
  } else {
    content.classList.add('collapsed');
    if (arrow) arrow.textContent = '▸';
  }
};
```

### 5. Update the Render Logic

- Replace inline display toggles with the new collapsible wrapper
- Move destructive/secondary buttons into the card header
- Ensure unique IDs when multiple cards share the same collapsible structure (e.g., `share-content-0`, `share-content-1`)

### 6. Verify and Push

- Check that the page renders correctly when logged in and logged out
- Confirm collapsing/expanding works on mobile
- Commit and push the changes

## Common Patterns

| Problem | Solution |
|---|---|
| Multiple secondary forms push primary content down | Merge into one collapsible card |
| Settings rarely changed consume vertical space | Collapse by default, expand on demand |
| Destructive action next to primary action | Move to header as icon-only button |
| Repeated collapsible sections need unique IDs | Append an index to both content and arrow IDs |

## Resources

No bundled resources are required for this skill. All code is added directly to the target SPA file.
